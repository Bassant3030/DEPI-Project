<?php

use App\Http\Controllers\CartController;
use App\Http\Controllers\FrontController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\DishesController;
use App\Http\Controllers\CuisineController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [FrontController::class, 'index'])->name('main');
Route::get('/cuisine/dish/{id}', [FrontController::class, 'showByDishId'])->name('cuisine.dish.show');
// orders routes

Route::get('/order/place', [OrderController::class, 'place'])->name('order.place');
Route::get('/order/show', [OrderController::class, 'show'])->name('order.show');
// cart routes
Route::get('/cart/add/{id}', [CartController::class, 'add'])->name('cart.add');
Route::get('/cart/show', [CartController::class, 'show'])->name('cart.show');
Route::get('/cart/delete/{id}', [CartController::class, 'delete'])->name('cart.delete');
Route::get('/cart/update/{id}', [CartController::class, 'update'])->name('cart.update');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Auth::routes();
// dish routes
Route::get('/dish/create', [DishesController::class, 'create'])->name('dish.create');
Route::get('/dish/index', [DishesController::class, 'index'])->name('dish.index');
Route::post('/dish/store', [DishesController::class, 'store'])->name('dish.store');
Route::get('/dish/destroy/{id}', [DishesController::class, 'destroy'])->name('dish.destroy');
Route::get('/dish/edit/{id}', [DishesController::class, 'edit'])->name('dish.edit');
Route::post('/dish/update/{id}', [DishesController::class, 'update'])->name('dish.update');


// cuisine routes
Route::get('/cuisine/create', [CuisineController::class, 'create'])->name('cuisine.create');
Route::get('/cuisine/index', [CuisineController::class, 'index'])->name('cuisine.index');
Route::post('/cuisine/store', [CuisineController::class, 'store'])->name('cuisine.store');
Route::get('/cuisine/destroy/{id}', [CuisineController::class, 'destroy'])->name('cuisine.destroy');
Route::get('/cuisine/edit/{id}', [CuisineController::class, 'edit'])->name('cuisine.edit');
Route::post('/cuisine/update/{id}', [CuisineController::class, 'update'])->name('cuisine.update');