<?php

namespace App\Service;

use App\Repository\Interface\ICuisineRepository;
use App\DTO\CuisineDTO;

class CuisineService
{
    private $cuisineRepository;
    public function __construct(ICuisineRepository $cuisineRepository)
    {
        $this->cuisineRepository = $cuisineRepository;
    }

    public function store($cuisineDTO)
    {
        $this->cuisineRepository->store($cuisineDTO);
    }

    public function update($cuisineDTO, String $id)
    {
        $this->cuisineRepository->update($cuisineDTO, $id);
    }

    public function all()
    {
        return $this->cuisineRepository->all();
    }

    public function destroy(string $id)
    {
        return $this->cuisineRepository->destroy($id);
    }

    public function findById(string $id)
    {
        return $this->cuisineRepository->findById($id);
    }
    public function getCuisineByDishId(string $id){
        return $this->cuisineRepository->getCuisineByDishId($id);
    }
}