<?php

namespace App\Service;

use App\DTO\DishesDTO;
use App\Http\Requests\DishesRequest;
use App\Repository\Interface\IDishesRepository;

class DishesService
{
    private $dishRepository;
    public function __construct(IDishesRepository $dishRepository)
    {
        $this->dishRepository = $dishRepository;
    }

    public function store(DishesDTO $dishDTO)
    {
        $this->dishRepository->store($dishDTO);
    }

    public function update(DishesDTO $dishDTO, String $id)
    {
        $this->dishRepository->update($dishDTO, $id);
    }

    public function all()
    {
        return $this->dishRepository->all();
    }

    public function destroy(string $id)
    {
        return $this->dishRepository->destroy($id);
    }

    public function findById(string $id)
    {
        return $this->dishRepository->findById($id);
    }
}