<?php

namespace App\Repository;

use App\Repository\Interface\ICuisineRepository;
use App\Models\Cuisine;

class CuisineRepository implements ICuisineRepository
{
    public function store($cuisineDTO)
    {
        Cuisine::create($cuisineDTO);
    }

    public function update($cuisineDTO, $id)
    {
        $cuisine = $this->findById($id);
        $cuisine->update($cuisineDTO);
    }

    public function all()
    {
        return Cuisine::all();
    }

    public function destroy(string $id)
    {
        $cuisine =  $this->findById($id);

        return $cuisine->delete();
    }
    public function findById(string $id)
    {
        return Cuisine::findOrFail($id);
    }
    public function getCuisineByDishId(string $id)
    {
        return Cuisine::where('id', $id)->get();
    }
}