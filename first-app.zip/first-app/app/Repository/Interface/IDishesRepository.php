<?php

namespace App\Repository\Interface;

use App\DTO\DishesDTO;

interface IDishesRepository
{
    public function store(DishesDTO $dishDTO);
    public function update(DishesDTO $dishDTO, String $id);
    public function all();
    public function destroy(String $id);
    public function findById(String $id);
}