<?php

namespace App\Repository\Interface;

use App\DTO\CuisineDTO;

interface ICuisineRepository
{
    public function store(CuisineDTO $cuisineDTO);
    public function update(CuisineDTO $cuisineDTO, String $id);
    public function all();
    public function destroy(String $id);
    public function findById(String $id);
    public function getCuisineByDishId(string $id);
}