<?php

namespace App\Repository;

use App\Http\Requests\DishesRequest;
use App\Repository\Interface\IDishesRepository;
use App\Models\Dishes;

class DishesRepository implements IDishesRepository
{
    public function store($dishDTO)
    {
        Dishes::create($dishDTO->toArray());
    }

    public function update($dishDTO, $id)
    {
        $dish = $this->findById($id);
        $dish->update($dishDTO->toArray());
    }

    public function all()
    {
        return Dishes::all();
    }

    public function destroy(string $id)
    {
        $dish =  $this->findById($id);

        return $dish->delete();
    }
    public function findById(string $id)
    {
        return Dishes::findOrFail($id);
    }
}