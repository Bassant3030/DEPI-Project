<?php

namespace App\Repository;

use App\Models\OrderDetails;
use App\Repository\Interface\IOrderDetailsRepository;
use App\Repository\Interface\ICuisineRepository;

class OrderDetailsRepository implements IOrderDetailsRepository
{
    private $cuisineRepository;
    public function __construct(ICuisineRepository $cuisineRepository)
    {
        $this->cuisineRepository = $cuisineRepository;
    }
    public function insert(string $id, object $cart)
    {

        foreach ($cart as $item) {
            OrderDetails::create([
                'order_id' => $id,
                'cuisine_id' => $item->id,
                'quantity' => $item->quantity,
                'merchant_id' => $this->cuisineRepository->findById($item->id)->merchant_id
            ]);
        }
    }
    public function getAllByMerchant(string $id)
    {
        return OrderDetails::where('merchant_id', $id)->get();
    }
}