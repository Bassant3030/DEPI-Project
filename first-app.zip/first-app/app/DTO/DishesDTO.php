<?php

namespace App\DTO;

use Spatie\LaravelData\Data;

class DishesDTO extends Data
{
    public function __construct(public string $title) {}
}