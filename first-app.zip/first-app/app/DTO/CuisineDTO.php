<?php

namespace App\DTO;

use App\Http\Requests\CuisineRequest;
use App\Http\Requests\UpdateCuisineRequest;
use Spatie\LaravelData\Data;
use Auth;

class CuisineDTO extends Data
{
    public function __construct(
        public string $title,
        public string $decription,
        public int $price,
        public int $stock,
        public int $dish_id,
        // public int $merchant_id,
        // public string $img,
    ) {}


    public static function handleInputs(CuisineRequest $request)
    {
        $data = [
            'title' => $request->title,
            'decription' => $request->decription,
            'price' => $request->price,
            'stock' => $request->stock,
            'dish_id' => $request->dish_id,
            'merchant_id' => Auth::id(),
        ];

        if ($request->img) {
            $img = $request->img;
            $img_new_name = time() . $img->getClientOriginalName();
            $img->move('img/', $img_new_name);
            $data['img'] = 'img/' . $img_new_name;
        }
        return $data;
    }
    public static function handleUpdateInputs(UpdateCuisineRequest $request)
    {
        $data = [
            'title' => $request->title,
            'decription' => $request->decription,
            'price' => $request->price,
            'stock' => $request->stock,
            'dish_id' => $request->dish_id,
            'merchant_id' => Auth::id(),
        ];

        if ($request->img) {
            $img = $request->img;
            $img_new_name = time() . $img->getClientOriginalName();
            $img->move('img/', $img_new_name);
            $data['img'] = 'img/' . $img_new_name;
        }
        return $data;
    }

}


