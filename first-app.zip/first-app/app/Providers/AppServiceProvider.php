<?php

namespace App\Providers;

use App\Repository\Interface\IOrderDetailsRepository;
use App\Repository\Interface\IOrderRepository;
use App\Repository\Interface\ICuisineRepository;
use App\Repository\Interface\IDishesRepository;
use App\Repository\OrderDetailsRepository;
use App\Repository\OrderRepository;
use App\Repository\CuisineRepository;
use App\Repository\DishesRepository;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->singleton(IDishesRepository::class, DishesRepository::class);
        $this->app->singleton(ICuisineRepository::class, CuisineRepository::class);
        $this->app->singleton(IOrderRepository::class, OrderRepository::class);
        $this->app->singleton(IOrderDetailsRepository::class, OrderDetailsRepository::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}