<?php

namespace App\Models;

use App\DTO\CuisineDTO;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrderDetails extends Model
{
    use HasFactory;
    protected $table = 'orders_details';
    protected $fillable = ['cuisine_id', 'merchant_id', 'order_id', 'quantity'];
    protected $with = ['merchant', 'cuisine'];
    public function orders()
    {
        return $this->BelongsTo(Order::class, 'order_id');
    }
    public function merchant()
    {
        return $this->belongsTo(User::class, 'merchant_id');
    }
    public function cuisine()
    {
        return $this->belongsTo(Cuisine::class, 'cuisine_id');
    }
}