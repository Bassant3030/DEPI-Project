<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cuisine extends Model
{
    use HasFactory;
    protected $table = 'cuisine';
    protected $fillable = ['title', 'decription', 'img', 'price', 'stock', 'merchant_id', 'dish_id'];
    protected $with = ['dishes'];
    public function dishes()
    {
        return $this->belongsTo(Dishes::class, 'dish_id');
    }
    public function orderDetails()
    {
        return $this->hasMany(OrderDetails::class, 'cuisine_id');
    }
}
