<?php

namespace App\Http\Controllers;

use App\Service\CartService;
use App\Service\CuisineService;
use Illuminate\Http\Request;
use App\Service\DishesService;

class CartController extends Controller
{
    private $cartService;
    private $cuisineService;
    private $dishService;
    public function __construct(CartService $cartService, CuisineService $cuisineService, DishesService $dishService)
    {
        $this->cartService = $cartService;
        $this->cuisineService = $cuisineService;
        $this->dishService = $dishService;
    }
    public function add($id)
    {
        $this->cartService->addItem($this->cuisineService->findById($id));
        return redirect()->back();
    }

    public function show()
    {
        // dd($this->cartService->getDetails());
        return view('front.cart', [
            'cart' => $this->cartService->getCart(),
            'dishes' => $this->dishService->all(),
            'cartTotalItems' => $this->cartService->getTotalItems(),
            'details' => $this->cartService->getDetails(),
        ]);
    }

    public function delete($id)
    {
        $this->cartService->removeItem($id);
        return redirect()->back();
    }
    public function update($id, Request $request)
    {
        $this->cartService->updateQuantity($id, $request->quantity);
        return redirect()->back();
    }
}