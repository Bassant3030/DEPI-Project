<?php

namespace App\Http\Controllers;

use App\DTO\CuisineDTO;
use App\DTO\CuisineDTO as DTOCuisineDTO;
use Illuminate\Http\Request;
use App\Http\Requests\CuisineRequest;
use App\Service\CuisineService;
use App\Service\DishesService;
use App\Http\Requests\UpdateCuisineRequest;
use Auth;

class CuisineController extends Controller
{
    private $cuisineService;
    private $dishService;
    public function __construct(CuisineService $cuisineService, DishesService $dishService)
    {
        $this->cuisineService = $cuisineService;
        $this->dishService = $dishService;
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $cuisine = $this->cuisineService->all();
        return view('cuisine.index', ['cuisine' => $cuisine]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('cuisine.create', ['dishes' => $this->dishService->all()]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CuisineRequest $request)
    {
        $this->cuisineService->store(CuisineDTO::handleInputs($request));
        return redirect()->route('cuisine.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return view('cuisine.edit', ['cuisine' => $this->cuisineService->findById($id), 'dishes' => $this->dishService->all()]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCuisineRequest $request, string $id)
    {
        $this->cuisineService->update(CuisineDTO::handleUpdateInputs($request), $id);
        return redirect()->route('cuisine.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->cuisineService->destroy($id);
        return redirect()->back();
    }
}