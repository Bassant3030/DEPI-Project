<?php

namespace App\Http\Controllers;

use App\Service\CartService;
use App\Service\CuisineService;
use App\Service\DishesService;
use Illuminate\Http\Request;

class FrontController extends Controller
{
    private $cuisineService;
    private $dishService;
    private $cartService;
    public function __construct(CuisineService $cuisineService, DishesService $dishService, CartService $cartService)
    {
        $this->cuisineService = $cuisineService;
        $this->dishService = $dishService;
        $this->cartService = $cartService;
    }
    public function index()
    {
        return view('front.cuisine', [
            'cuisine' => $this->cuisineService->all(),
            'dishes' => $this->dishService->all(),
            'cartTotalItems' => $this->cartService->getTotalItems()
        ]);
    }

    public function showByDishId($id)
    {
        return view('front.show', [
            'cuisine' => $this->cuisineService->getCuisineByDishId($id),
            'dishes' => $this->dishService->all(),
            'cartTotalItems' => $this->cartService->getTotalItems()
        ]);
    }
}