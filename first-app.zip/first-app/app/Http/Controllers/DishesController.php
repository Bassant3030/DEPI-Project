<?php

namespace App\Http\Controllers;

use App\DTO\DishesDTO;
use App\Http\Requests\DishesRequest;
use App\Service\DishesService;
use Illuminate\Http\Request;

class DishesController extends Controller
{
    private $dishService;
    public function __construct(DishesService $dishService)
    {
        $this->dishService = $dishService;
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $dish = $this->dishService->all();
        return view('dish.index', ['dishes' => $dish]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('dish.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(DishesRequest $request)
    {
        $this->dishService->store(DishesDTO::from($request));
        return redirect()->route('dish.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return view('dish.edit', ['dishes' => $this->dishService->findById($id)]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(DishesRequest $request, string $id)
    {
        $this->dishService->update(DishesDTO::from($request), $id);
        return redirect()->route('dish.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->dishService->destroy($id);
        return redirect()->back();
    }
}