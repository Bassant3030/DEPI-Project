@extends('layouts.app')

@section('content')
<div class="card">
    <div class="card-header">Show cuisines</div>

    <div class="card-body">
        @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
        @endif

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">title</th>
                    <th scope="col">stock</th>
                    <th scope="col">price</th>
                    <th scope="col">image</th>
                    <th scope="col">actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($cuisine as $cuisines)
                <tr>
                    <th scope="row">{{$cuisines->id}}</th>
                    <td>{{$cuisines->title}}</td>
                    <td>{{$cuisines->stock}}</td>
                    <td>{{$cuisines->price}} LE</td>
                    <td><img src="{{asset($cuisines->img)}}" alt="" width="50"></td>
                    <td><a href="{{route('cuisine.destroy',['id' => $cuisines->id])}}">Delete</a></td>
                    <td><a href="{{route('cuisine.edit',['id' => $cuisines->id])}}">Edit</a></td>
                </tr>
                @endforeach

            </tbody>
        </table>
    </div>
</div>

@endsection