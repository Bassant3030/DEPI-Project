@extends('layouts.app')

@section('content')
<div class="card">
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
    <div class="card-header">Create cuisine</div>

    <div class="card-body">
        @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
        @endif

        <form action="{{route('cuisine.update',['id' => $cuisine->id])}}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="mt-3">
                <label for="" class="form-label">Enter cuisine Title</label>
                <input type="text" class="form-control" name="title" value="{{$cuisine->title}}">
            </div>
            <div class="mt-3">
                <label for="" class="form-label">Enter cuisine decription</label>
                <input type="text" class="form-control" name="decription" value="{{$cuisine->decription}}">
            </div>
            <div class="mt-3">
                <label for="" class="form-label">Enter cuisine price</label>
                <input type="number" class="form-control" name="price" value="{{$cuisine->price}}">
            </div>
            <div class="mt-3">
                <label for="" class="form-label">Enter cuisine stock</label>
                <input type="number" class="form-control" name="stock" value="{{$cuisine->stock}}">
            </div>
            <div class="mt-3">
                <label for="" class="form-label">upload cuisine image</label>
                <input type="file" class="form-control" name="img">
                <img src="{{asset($cuisine->img)}}" alt="" width="150">
            </div>
            <div class="mt-3">
                <label for="" class="form-label">Select dish</label>
                <select name="dish_id" class="form-select" aria-label="Default select example">
                    <option selected value="{{$cuisine->dish_id}}">{{$cuisine->dishes->title}}</option>
                    @foreach($dishes as $mark)
                    <option value="{{$mark->id}}">{{$mark->title}}</option>
                    @endforeach
                </select>
            </div>
            <button role="submit" class="btn btn-dark w-100 mt-3">Update</button>
        </form>
    </div>
</div>

@endsection